console.log("linked")

function addtocart(cartAmount){
    cartAmount.innerText++;
}

function change(wrd){
    if (wrd.innerText === 'Best Selling') {
        wrd.innerText = "Price"
    }
}